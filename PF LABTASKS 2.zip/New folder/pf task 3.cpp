#include<iostream>
using namespace std;
int main()
{cout<<"+++++++++++++++++++++++++++++++++++"<<endl<<
      "++++++++++++++++++++++++++++++++++++"<<endl<<
      "welcoming to programmimgfundamentals"<<endl<<
      "++++++++++++++++++++++++++++++++++++"<<endl<<
      "++++++++++++++++++++++++++++++++++++"<<endl<<
      "----------------------"<<endl;
return 0;

}
