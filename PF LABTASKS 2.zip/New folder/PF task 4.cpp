#include<iostream>
using namespace std;
int main()
{string name="laiba maryam";
int sapid = 64419;
string semester="1st semester";
string coursename ="computer science";
cout<<"student name:"<< name<<endl;
cout<<"sap id:"<< sapid<<endl;
cout<<"semester="<< semester<<endl;
cout<<"course name="<< coursename<<endl;

}
